<?php defined('BASEPATH') OR exit('No direct script access allowed');
$config['apps']      = 'CMS Sekolahku';
$config['version']   = 'v2.2.0';
$config['webmaster'] = 'Anton Sofyan';
$config['email']     = '4ntonsofyan@gmail.com';
$config['website']   = 'http://sekolahku.web.id';